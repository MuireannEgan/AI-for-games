using UnityEngine;

public class MonsterChase
{
private Transform target;

public MonsterMovement movement;

public MonsterChase(Transform player, MonsterMovement monsterMovement)
    {
        target = player;
        movement = monsterMovement;
    }


public void Execute()
{
    if (target == null || movement == null)
        return;

    movement.MoveTo(target.position, movement.chaseSpeed);
}

   

}
